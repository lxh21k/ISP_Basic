#include <opencv2/opencv.hpp>

int main(){
	
   std::cout << "Start here" << std::endl;
    /*************************


       code

    *************************/
    return 0;
}
